//const mongoClient = require("mongodb").MongoClient;

//const url = "mongodb://localhost:27017/";

//let users = [{name: "Bob", age: 34} , {name: "Alice", age: 21}, {name: "Tom", age: 45}];
let users = [{name: "DUI-LIQUOR", score: 10919},{name: "CHILD-OTHER", score: 4385},{name: "SEXOFF-OTHER", score: 2502},{name: "BURGLARY-FORCE-RES", score: 26909},{name: "THEFT-CARPROWL", score: 15104},{name: "SEXOFF-SODOMY", score:305}];
/*mongoClient.connect(url, function(err, client) {

    const db = client.db("usersdb");
    const collection = db.collection("users");

   collection.insertMany(users, function (err, results) {

        console.log(results);
    });
    if (err) return console.log(err);

    collection.find().toArray(function(err, results) {

        console.log(results);
        client.close();
    });
	
    db.collection("users").drop(function(err, result){

        console.log(result);
        client.close();
    });
});*/

const express = require("express");
const bodyParser = require("body-parser");
const mongoClient = require("mongodb").MongoClient;
const objectId = require("mongodb").ObjectID;

const app = express();
const jsonParser = bodyParser.json();
const url = "mongodb://localhost:27017/usersdb";

app.use(express.static(__dirname + "/public"));
app.get("/api/users", function(req, res){

    mongoClient.connect(url, function(err, client){
        client.db("usersdb").collection("users").find({}).toArray(function(err, users){
            res.send(users)
            client.close();
        });
    });
});
app.get("/api/users/:id", function(req, res){

    var id = new objectId(req.params.id);
    mongoClient.connect(url, function(err, client){
        client.db("usersdb").collection("users").findOne({_id: id}, function(err, user){

            if(err) return res.status(400).send();

            res.send(user);
            client.close();
        });
    });
});

app.post("/api/users", jsonParser, function (req, res) {

    if(!req.body) return res.sendStatus(400);

    var userName = req.body.name;
    var userAge = req.body.score;
    var user = {name: userName, score: userAge};

    mongoClient.connect(url, function(err, client){
        client.db("usersdb").collection("users").insertOne(user, function(err, result){

            if(err) return res.status(400).send();

            res.send(user);
            client.close();
        });
    });
});

app.delete("/api/users/:id", function(req, res){

    var id = new objectId(req.params.id);
    mongoClient.connect(url, function(err, client){
        client.db("usersdb").collection("users").findOneAndDelete({_id: id}, function(err, result){

            if(err) return res.status(400).send();

            var user = result.value;
            res.send(user);
            client.close();
        });
    });
});

app.put("/api/users", jsonParser, function(req, res){

    if(!req.body) return res.sendStatus(400);
    var id = new objectId(req.body.id);
    var userName = req.body.name;
    var userAge = req.body.score;

    mongoClient.connect(url, function(err, client){
        client.db("usersdb").collection("users").findOneAndUpdate({_id: id}, { $set: {score: userAge, name: userName}},
            {returnOriginal: false },function(err, result){

                if(err) return res.status(400).send();

                var user = result.value;
                res.send(user);
                client.close();
            });
    });
});

app.listen(3000, function(){
    console.log("Сервер ожидает подключения...");
});